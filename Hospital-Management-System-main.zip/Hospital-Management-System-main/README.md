# Hospital-Management-System
This project is designed to streamline healthcare management by providing essential features to manage patient and doctor information, book appointments, and check doctor availability.
